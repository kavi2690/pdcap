package Admin;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class c1 {
	ChromeDriver n;
	@Test(priority=0)
	public void loginpage() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Documents\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");
		
		n = new ChromeDriver();
		
		n.get("https://hywebdemo.com/pdcap/admin/login");
		
//		System.out.println(n.getCurrentUrl());
//		
//		System.out.println(n.getTitle());
//		
//		n.manage().window().maximize();
//		
//		n.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		
//		Thread.sleep(2000);	
//		
	}
	
//	@Test(priority=1)
//	public void User_name_() throws InterruptedException {
//		
//		n.findElement(By.name("email")).sendKeys("hyrrokkinteam@gmail.com");
//		
//		Thread.sleep(2000);	
//	}
//	
//	@Test(priority=2)
//	public void Password() throws InterruptedException {
//		
//		n.findElement(By.name("password")).sendKeys("123456789");
//		
//		Thread.sleep(2000);	
//	}
//	
//	@Test(priority=3)
//	public void Clicking_login() throws InterruptedException {
//		
//		n.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
//		
//		Thread.sleep(2000);		
//	}
//	@Test(priority=4)
//	public void click_drop_down() throws InterruptedException {
//		
//		//profile icon
//		
//		n.findElement(By.xpath("/html/body/div/header/div/nav/div[3]/a")).click();
//		
//		Thread.sleep(2000);	
//		
//		//profile
//		
//		n.findElement(By.xpath("/html/body/div/header/div/nav/div[3]/ul/li[1]/a/span")).click();
//		
//		Thread.sleep(2000);	
//		
//		n.navigate().back();
//		
//		
//	}
//	@Test(priority=5)
//	public void click_change_password() throws InterruptedException {
//		
//		//profile icon
//		
//		n.findElement(By.xpath("/html/body/div/header/div/nav/div[3]/a")).click();
//		
//		Thread.sleep(2000);	
//		
//		//change password
//		
//		n.findElement(By.xpath("html/body/div/header/div/nav/div[3]/ul/li[2]/a/span")).click();
//		
//		Thread.sleep(2000);	
//		
//		n.navigate().back();
//		
//		
//		
//	}
	
	
//	@Test(priority=6)
//	public void Manage_profile() throws InterruptedException {
//		
//		//Thread.sleep(1000);	
//		
//		n.findElement(By.xpath("//div[contains(text(), 'Manage Jobs')]")).click();
//		
//		//button[@class='btn btn-dark']
//		
//		
//		
//	}
//	
//	@Test(priority=7)
//	public void Create_manage_jobs() throws InterruptedException {
//		
//		Thread.sleep(2000);	
//		
//		n.findElement(By.xpath("//button[@data-bs-target='#Create']")).click();
//		
//		//create customer enter name
//		
//		
//		Thread.sleep(2000);	
//		
//		n.findElement(By.name("name")).sendKeys("surya");
//		
//		
//		Thread.sleep(2000);	
//		
//		//enter the email 
//		
//		n.findElement(By.name("email")).sendKeys("kavi@234gmail.com");
//		
//		Thread.sleep(2000);	
//	
//	}
//	@Test(priority=8)
//	public void drop_down() throws InterruptedException {
//		
////		WebElement m = n.findElement(By.xpath(""));
////		
////		Select g= new Select(m) ;
////		g.selectByIndex(4);
//		
//		n.findElement(By.xpath("//*[@id=\"create-form\"]/div[1]/div[3]/div")).click();
//		
//		Thread.sleep(1000);
//		
//		n.findElement(By.xpath("//label[contains(text(), 'software students')]")).click();
//		
//		
//	}
//	
//	@Test(priority=9)
//	public void submit() throws InterruptedException {
//		
//		Thread.sleep(2000);	
//		
//		n.findElement(By.xpath("//*[@id=\"create-form\"]/div[2]/button[2]")).click();
//		
//		//n.findElement(By.linkText("Create ")).click();
//		
//	}
	
//	@Test(priority=10)
//	public void search() throws InterruptedException {
//		
//		Thread.sleep(2000);
//		
//		n.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[2]/div/div/div/form/div/div[3]/div/input")).sendKeys("kavi");
//		
//		Thread.sleep(2000);
//		
//		n.findElement(By.xpath("//button[@class='btn btn-primary btn-sm']")).click();
//		
//		Thread.sleep(2000);
//		
//		
//		
//	}
//	
//	@Test(priority=11)
//	public void Drop_down() throws InterruptedException {
//		
//		    n.executeScript("window.scrollBy(0,1000)");
//		   
//			Thread.sleep(2000);
//			
//			n.executeScript("window.scrollBy(0,-1000)");
//			
//			Thread.sleep(2000);
//	}
//	
	
//	@Test(priority=12)
//	public void click_on_the_view() throws InterruptedException {
//		
//		n.findElement(By.xpath(" /html/body/div[1]/div[3]/div/div[2]/div/table/tbody/tr[1]/td[10]/a")).click();
//		
//		Thread.sleep(2000);
//		
//		
//	}
	
//	@Test(priority=13)
//	public void view_pages_allcategorys() throws InterruptedException {
		
//		n.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[2]/div/ul/li[1]/a")).click();
//		
//		Thread.sleep(2000);
		
//		n.findElement(By.xpath("//a[contains(text(), \"Package Info\")]")).click();
//		
//		Thread.sleep(2000);
//		
//		n.findElement(By.xpath("//a[contains(text(), \"Consultation\")]")).click();
//		
//		Thread.sleep(2000);
//		
//		n.findElement(By.xpath("//a[contains(text(), \"Riasec Assessment\")]")).click();
//		
//		Thread.sleep(2000);
//		
//		n.findElement(By.xpath("//a[contains(text(), \"Casve Assessment\")]")).click();
//		
//		Thread.sleep(2000);
//		
//		n.navigate().back();
//		
//		Thread.sleep(2000);
//		
//		n.navigate().back();
//		
//		Thread.sleep(2000);
//		
//		
//		n.navigate().back();
//		
//		Thread.sleep(2000);
//		
//		n.navigate().back();
//		
//		
//		Thread.sleep(2000);
//		
//		n.navigate().back();
//		
//		
//			
//		
//	}
//	

//	@Test(priority=14)
//	public void Package_Info() throws InterruptedException {
//		
	
		
		
//		WebElement k = n.findElement(By.xpath("/html/body/div/div[3]/div/div[2]/div/form/div/div[1]/div/p/span"));
//		
//		Select drop= new Select(k);
//		
//		drop.selectByIndex(1);
//		
//		
//		Thread.sleep(2000);
//		
//		
//		n.findElement(By.xpath("//button[@type='submit']")).click();
//		
		
//		n.findElement(By.xpath("body > div.wrapper > div.page-wrapper > div > div.card > div > form > div > div:nth-child(1) > div > p > span")).click();
//		
//		Thread.sleep(2000);
//		
//		n.findElement(By.xpath("//option[@data-regular-price='230']")).click();
//		
//		Thread.sleep(2000);
//}	 m,.;'
	
	
//	@Test(priority=15)
//	public void mange() throws InterruptedException {
//		
//		n.findElement(By.xpath("//div[contains(text(), 'Manage Jobs')]")).click();
//	}
//		
//	@Test(priority=16)
//	public void reset() throws InterruptedException {
//		
//		Thread.sleep(2000);
//		
//		n.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[2]/div/div/div/form/div/div[5]/div")).click();
//		
//		
//		
//	}
	
	////input[@type='submit']
	
//	@Test(priority=17)
//	public void disable() throws InterruptedException {
//		
//		Thread.sleep(2000);
//		
//		n.findElement(By.xpath("//input[@type='submit']")).click();
//		
//	}
	
	//div[contains(text(), 'Masters')]
	@Test(priority=18)
	public void master() throws InterruptedException {
		
		Thread.sleep(2000);
		
		n.findElement(By.xpath("//*[@id=\"menu\"]/li[3]/a/div[2]")).click();
		
	}
	
//	@Test(priority=19)
//	public void country() throws InterruptedException {
//		
//		Thread.sleep(2000);
//		
//		n.findElement(By.xpath("//a[@href='https://hywebdemo.com/pdcap/admin/country']")).click();
//		
//		//n.findElement(By.xpath("//*[@id=\"menu\"]/li[3]/ul/li[1]/a")).click();
//		
//	}
	
//	
	
//	@Test(priority=19)
//	public void create() throws InterruptedException {
//		
//		Thread.sleep(2000);
//		
//		n.findElement(By.xpath("//button[@class='btn btn-dark']")).click();
//		
//		Thread.sleep(2000);
//		
//		n.findElement(By.name("code")).sendKeys("87");
//		
//		Thread.sleep(2000);
//		
//		n.findElement(By.name("name")).sendKeys("mksd");
//		
//		Thread.sleep(2000);
//		
//		n.findElement(By.xpath("//button[@class='btn btn-success create-button']")).click();
//		
//		Thread.sleep(2000);
//		
//		
//		
//	}
	
	//button[@data-id='48']
	
//
//	@Test(priority=20)
//	public void State () throws InterruptedException {
//		
//		Thread.sleep(2000);
//		
//		n.findElement(By.xpath("//a[@href='https://hywebdemo.com/pdcap/admin/state']")).click();
//		
//		Thread.sleep(2000);
//		
//		//craete
//       
//		
//		//Edit
//	    //n.findElement(By.xpath("/html/body/div/div[3]/div/div[2]/div/table/tbody/tr[1]/td[6]/button")).click();
//		
//		
//	}
//	
//	
//	@Test(priority=21)
//	public void select_the_value () throws InterruptedException {
//		
//		    n.findElement(By.xpath("//button[@class='btn btn-dark']")).click();
//			
//			Thread.sleep(2000);
//			
//		    n.findElement(By.xpath("//*[@id=\"create-form\"]/div[1]/div[1]/div/p/label/i"));
//			
//		    Thread.sleep(2000);
//		    
//		    n.findElement(By.xpath("//option[@value='1']")).click();
//		    
//		    Thread.sleep(2000);
//		    
//		    n.findElement(By.name("name")).sendKeys("mkl");
//		    
//		    Thread.sleep(2000);
//		    
//		    n.findElement(By.name("num_code")).sendKeys("+99");
//		    
//		    Thread.sleep(2000);
//		    
//		    n.findElement(By.xpath("//button[@class='btn btn-success create-button']")).click();
////			
//			Thread.sleep(2000);
//			
//		
//		    
//		    
//			
//			
//	}
//	
//	@Test(priority=22)
//	public void Edit () throws InterruptedException {
//		
//		//n.findElement(By.xpath("/html/body/div/div[3]/div/div[2]/div/table/tbody/tr[1]/td[6]/button")).click();
//		
//		n.findElement(By.xpath("/html/body/div/div[3]/div/div[2]/div/table/tbody/tr[1]/td[6]/button")).click();
//		
//
//	    n.findElement(By.xpath("//*[@id=\"create-form\"]/div[1]/div[1]/div/p/label/i"));
//		
//	    Thread.sleep(2000);
//	    
//	    n.findElement(By.xpath("//option[@value='1']")).click();
//	    
//	    Thread.sleep(2000);
//	    
//	    n.findElement(By.name("name")).sendKeys("klm");
//	    
//	    Thread.sleep(2000);
//	    
//	    n.findElement(By.name("num_code")).sendKeys("+990");
//	    
//	    Thread.sleep(2000);
//	    
//	    n.findElement(By.xpath("//button[@class='btn btn-success create-button']")).click();
////		
//		Thread.sleep(2000);
//		
//		
//	}
//	
//	
//		
//	
//	
//	
//	
//	
//
//	
	
	
}
